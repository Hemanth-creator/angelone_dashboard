"""
Indian Intraday Scanner - a live Streamlit dashboard over Angel One SmartAPI.

Run with:
    streamlit run app.py

Single-page layout: a "Recommended" table on top (stocks appearing in 2+ of
Gainers / Losers / Most Active / Volume Surge), then every screener in a grid,
then a "Seen today" log of every stock that was ever recommended.
Only the data panel refreshes (st.fragment), so the page never dims or reloads.
"""

import time
import warnings

import pandas as pd
import streamlit as st

# Comparing NaN (stocks with no volume/range data yet) is expected and harmless.
warnings.filterwarnings("ignore", message="invalid value encountered", category=RuntimeWarning)

from auth import AuthError, get_session
from universe import build_universe
from quotes import fetch_quotes
from historical import fetch_avg_volume_20d, fetch_opening_range
from ist_time import now_ist, market_open_today, market_close_today, is_market_hours, is_trading_day
from recommend import recommended, update_seen, seen_table, reset_seen
import screeners as scr

st.set_page_config(page_title="Indian Intraday Scanner", layout="wide", page_icon="📈")

# ---------------------------------------------------------------------------
# Styling - compact, and NO dimming while data refreshes
# ---------------------------------------------------------------------------
st.markdown("""
<style>
    .block-container { padding-top: 1rem; padding-bottom: 1rem; max-width: 100%; }
    [data-testid="stMetricValue"] { font-size: 1.2rem; }
    h1 { font-size: 1.6rem !important; padding-bottom: 0 !important; }
    /* keep everything fully visible while the script/fragment is running */
    [data-stale="true"], .stale-element, div[data-stale="true"] {
        opacity: 1 !important; transition: none !important;
    }
    [data-testid="stStatusWidget"] { visibility: hidden; }
</style>
""", unsafe_allow_html=True)


def color_pct(val):
    if pd.isna(val):
        return ""
    color = "#1fbf5c" if val > 0 else ("#e2493d" if val < 0 else "")
    return f"color: {color}; font-weight: 600;"


def color_label(val):
    if val in ("Bullish", "Gap Up", "Above", "On list"):
        return "color: #1fbf5c; font-weight: 700;"
    if val in ("Bearish", "Gap Down", "Below"):
        return "color: #e2493d; font-weight: 700;"
    return ""


def style_table(df: pd.DataFrame, pct_cols: list[str]):
    sty = df.style
    for col in pct_cols:
        if col in df.columns:
            sty = sty.map(color_pct, subset=[col])
    for col in ("bias", "direction", "vwap_pos", "status", "bias_when_seen"):
        if col in df.columns:
            sty = sty.map(color_label, subset=[col])
    fmt = {}
    for col in df.columns:
        if col in ("ltp", "open", "high", "low", "close", "avgPrice", "or_high", "or_low",
                   "day_open", "prev_close", "first_price"):
            fmt[col] = "₹{:.2f}"
        elif col in ("percentChange", "vwap_dev_pct", "gap_pct", "pct_beyond_range",
                     "since_first_pct", "in_bias_pct"):
            fmt[col] = "{:+.2f}%"
        elif col in ("volume", "avg_volume_20d", "turnover"):
            fmt[col] = "{:,.0f}"
        elif col == "turnover_cr":
            fmt[col] = "{:,.1f}"
        elif col == "rvol":
            fmt[col] = "{:.2f}x"
    return sty.format(fmt, na_rep="-")


def show(title, df, pct_cols, cols=None, empty_msg="Nothing matching right now.", max_rows=None):
    """Render one titled, auto-height table (no inner scrolling unless max_rows is set)."""
    if title:
        st.markdown(f"**{title}**")
    if df is None or df.empty:
        st.caption(empty_msg)
        return
    df = df.copy()
    if "turnover" in df.columns:
        df["turnover_cr"] = df["turnover"] / 1e7  # rupees -> crore
    if cols:
        df = df[[c for c in cols if c in df.columns]]
    visible = len(df) if max_rows is None else min(len(df), max_rows)
    height = 35 * (visible + 1) + 3
    st.dataframe(style_table(df, pct_cols), width="stretch",
                 hide_index=True, height=height)


# ---------------------------------------------------------------------------
# Sidebar controls
# ---------------------------------------------------------------------------
st.sidebar.title("⚙️ Scanner Controls")

st.sidebar.radio("Universe", ["Nifty 200 (recommended)"], index=0,
                 help="Stock universe scanned each cycle.")
refresh_secs = st.sidebar.slider("Auto-refresh interval (sec)", 10, 60, 20, step=5)
row_count = st.sidebar.slider("Rows per table", 5, 30, 10, step=5)
tables_per_row = st.sidebar.slider("Tables per row", 2, 4, 3)
st.sidebar.markdown("**Recommendation**")
min_lists = st.sidebar.slider("Min. tables a stock must appear in", 2, 4, 2)
st.sidebar.markdown("**Thresholds**")
rvol_threshold = st.sidebar.slider("Volume Surge: min RVOL", 1.5, 5.0, 2.0, step=0.5)
vwap_threshold = st.sidebar.slider("VWAP: min deviation %", 0.2, 3.0, 0.5, step=0.1)
gap_threshold = st.sidebar.slider("Gap scanner: min gap %", 0.5, 5.0, 2.0, step=0.5)

st.sidebar.markdown("---")
if st.sidebar.button("🗑 Reset 'Seen today' log"):
    reset_seen()
if st.sidebar.button("🔄 Force full refresh (re-login + reload universe)"):
    st.session_state.clear()
    st.cache_data.clear()
    st.cache_resource.clear()
    st.rerun()

st.sidebar.caption(
    "Data: Angel One SmartAPI (your account). Rankings are computed live from "
    "quotes across the universe. Screens are for your own analysis, not "
    "investment advice."
)

# ---------------------------------------------------------------------------
# Session / data loading
# ---------------------------------------------------------------------------


@st.cache_resource(show_spinner="Logging into Angel One...")
def _get_client():
    return get_session()


def _get_client_fresh():
    """Force a brand-new login (used for auto-recovery on an expired token)."""
    _get_client.clear()
    return get_session(force_relogin=True)


@st.cache_data(ttl=24 * 3600, show_spinner="Building Nifty 200 universe...")
def _get_universe():
    return build_universe()


def _progress_updater(bar, label):
    def _update(done, total, elapsed, remaining):
        mins, secs = divmod(int(remaining), 60)
        bar.progress(
            done / total,
            text=f"{label}: {done}/{total} stocks ({done/total*100:.0f}%) "
                 f"— elapsed {int(elapsed)}s, ETA ~{mins}m {secs}s",
        )
    return _update


@st.cache_data(ttl=24 * 3600, show_spinner=False)
def _get_avg_volume(_client, universe):
    smart_api, _, _ = _client
    progress = st.progress(0.0, text="Loading 20-day average volumes (one-time, usually 3-6 min)...")
    df = fetch_avg_volume_20d(smart_api, universe, progress_cb=_progress_updater(progress, "Average volume"))
    progress.empty()
    return df


@st.cache_data(ttl=24 * 3600, show_spinner=False)
def _get_opening_range(_client, universe):
    smart_api, _, _ = _client
    progress = st.progress(0.0, text="Loading today's opening range (one-time)...")
    df = fetch_opening_range(smart_api, universe, minutes=15, progress_cb=_progress_updater(progress, "Opening range"))
    progress.empty()
    return df


EMPTY_OPENING_RANGE_COLS = ["name", "token", "or_high", "or_low", "day_open"]

# ---------------------------------------------------------------------------
# Market timing (IST)
# ---------------------------------------------------------------------------
OPENING_RANGE_MINUTES = 15
now_time_ist = now_ist()
opening_range_ready_at = market_open_today() + pd.Timedelta(minutes=OPENING_RANGE_MINUTES)
opening_range_has_formed = is_trading_day(now_time_ist) and now_time_ist >= opening_range_ready_at

# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------
try:
    smart_api, feed_token, client_code = _get_client()
except AuthError as e:
    st.error(f"❌ Login failed: {e}")
    st.info("Check your `.env` file against `.env.example` and make sure your "
            "Angel One SmartAPI app, TOTP, and PIN are all set up correctly.")
    st.stop()

# Keep the live API handle in session_state so the refresh fragment can swap
# in a fresh login without a full page rerun.
st.session_state.setdefault("api", smart_api)

universe = _get_universe()
if universe.empty:
    with st.spinner("Universe came back empty, retrying..."):
        time.sleep(3)
        _get_universe.clear()
        universe = _get_universe()
    if universe.empty:
        st.error("Could not build a stock universe. Check your internet connection and reload.")
        st.stop()

avg_volume = _get_avg_volume((smart_api, feed_token, client_code), universe)

if opening_range_has_formed:
    opening_range = _get_opening_range((smart_api, feed_token, client_code), universe)
else:
    opening_range = pd.DataFrame(columns=EMPTY_OPENING_RANGE_COLS)

st.title("📈 Indian Intraday Scanner")


# ---------------------------------------------------------------------------
# Live panel: only this fragment re-runs every refresh_secs, so the rest of
# the page stays put and nothing dims.
# ---------------------------------------------------------------------------
@st.fragment(run_every=refresh_secs)
def live_panel():
    now = now_ist()
    market_open = is_market_hours(now)

    # Opening range becomes available mid-session: do one full rerun to load it.
    if (not opening_range_has_formed) and is_trading_day(now) and now >= opening_range_ready_at:
        st.rerun(scope="app")

    api = st.session_state["api"]
    live = fetch_quotes(api, universe)
    if live.empty:
        try:
            api, _, _ = _get_client_fresh()
            st.session_state["api"] = api
            live = fetch_quotes(api, universe)
        except AuthError as e:
            st.error(f"Re-login failed: {e}")
            return

    if live.empty:
        if market_open:
            st.error("No live quote data returned. Retrying on the next refresh.")
        else:
            st.info("No quote data available right now. Retrying on the next refresh.")
        return

    now = now_ist()
    rec = recommended(live, avg_volume, n=row_count, min_rvol=rvol_threshold, min_lists=min_lists)
    # Log picks only while the market is open, so after-hours snapshots don't pollute the day's log.
    seen = update_seen(rec, record=market_open)

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Market", "🟢 OPEN" if market_open else "🔴 CLOSED")
    m2.metric("Last update (IST)", now.strftime("%H:%M:%S"))
    m3.metric("Universe", len(universe))
    m4.metric("Recommended", len(rec))
    if not market_open:
        st.caption("Market closed (NSE 9:15–15:30 IST, Mon–Fri) — showing the last available quotes.")

    # ---- Recommended ----
    st.markdown("### ⭐ Recommended Stocks")
    st.caption(f"Stocks appearing in {min_lists}+ of: Top Gainers, Top Losers, Most Active, Volume Surge "
               f"(top {row_count} of each). Bias follows today's price change.")
    show("", rec, ["percentChange"],
         cols=["name", "bias", "vwap_pos", "hits", "appears_in", "ltp", "avgPrice", "vwap_dev_pct",
               "percentChange", "turnover_cr", "volume", "rvol"],
         empty_msg="No stock is in 2+ tables right now. Try raising 'Rows per table' or lowering the RVOL threshold.")

    # ---- Screener grid ----
    gainers = scr.top_gainers(live, n=row_count)
    losers = scr.top_losers(live, n=row_count)
    active = scr.most_active(live, n=row_count)
    high_vol = scr.high_volume(live, n=row_count)
    surge = scr.volume_surge(live, avg_volume, min_rvol=rvol_threshold, n=row_count)
    above, below = scr.vwap_crossover(live, min_deviation_pct=vwap_threshold, n=row_count)
    gap_df, orb_up, orb_down = scr.gap_and_opening_range(
        live, opening_range, min_gap_pct=gap_threshold, n=row_count)

    orb_msg = (f"Opening range forms at {opening_range_ready_at.strftime('%H:%M')} IST."
               if not opening_range_has_formed else "Nothing matching right now.")

    base = ["name", "ltp", "percentChange"]
    panels = [
        ("🟢 Top Gainers", gainers, ["percentChange"], base + ["turnover_cr"], None),
        ("🔴 Top Losers", losers, ["percentChange"], base + ["turnover_cr"], None),
        ("💰 Most Active (₹ Cr traded)", active, ["percentChange"], base + ["turnover_cr"], None),
        ("⚡ Volume Surge (RVOL)", surge, ["percentChange"], base + ["rvol"], None),
        ("📊 High Volume (shares)", high_vol, ["percentChange"], base + ["volume"], None),
        ("🌅 Gap Scanner", gap_df, ["gap_pct", "percentChange"],
         ["name", "direction", "gap_pct", "ltp", "percentChange"], None),
        ("📐 Above VWAP (bullish)", above, ["vwap_dev_pct"],
         ["name", "ltp", "avgPrice", "vwap_dev_pct"], None),
        ("📐 Below VWAP (bearish)", below, ["vwap_dev_pct"],
         ["name", "ltp", "avgPrice", "vwap_dev_pct"], None),
        ("🚀 Range Breakout ↑", orb_up, ["pct_beyond_range"],
         ["name", "ltp", "or_high", "pct_beyond_range"], orb_msg),
        ("🔻 Range Breakdown ↓", orb_down, ["pct_beyond_range"],
         ["name", "ltp", "or_low", "pct_beyond_range"], orb_msg),
    ]

    st.markdown("### 📋 Screeners")
    for i in range(0, len(panels), tables_per_row):
        cols = st.columns(tables_per_row)
        for col, (title, df, pcts, view, msg) in zip(cols, panels[i:i + tables_per_row]):
            with col:
                kwargs = {"empty_msg": msg} if msg else {}
                show(title, df, pcts, cols=view, **kwargs)

    # ---- Seen today (below everything) ----
    st.markdown("### 🕘 Seen Today")
    st.caption("Every stock that appeared in the Recommended list today, newest first. "
               "**since_first_pct** = price change since it first appeared; **in_bias_pct** = same, "
               "but + means it moved the way its bias predicted (up for Bullish, down for Bearish). "
               "**refreshes** = number of refresh cycles it stayed on the list. "
               "Logged only while the market is open.")
    show("", seen_table(seen, live, set(rec["name"])),
         ["since_first_pct", "in_bias_pct"],
         cols=["name", "status", "bias_when_seen", "first_seen", "last_seen", "first_price", "ltp",
               "since_first_pct", "in_bias_pct", "max_hits", "refreshes"],
         empty_msg="Nothing logged yet. Picks are recorded here while the market is open (09:15–15:30 IST).",
         max_rows=15)

    st.caption(f"Auto-refreshing every {refresh_secs}s · only this panel reloads. "
               f"Gap & range-breakout use the first {OPENING_RANGE_MINUTES}-min range.")


live_panel()