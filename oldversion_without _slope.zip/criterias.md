# How a Stock Ends Up in Each Table

This explains exactly what each table on the dashboard does, based on the code in `screeners.py`, `recommend.py` and `app.py`.

**Common to all tables**

- **Universe:** about 200 stocks (the Nifty 200 list). Nothing outside it is ever shown, however big its move.
- **Refresh:** every table is rebuilt from scratch on each refresh (default 20 s) from one fresh quote snapshot. There is no memory between refreshes, so stocks move in and out.
- **N (Rows per table, default 10):** each table shows at most N rows. The filter is applied first, then the top N are kept, so a table can have fewer than N rows.
- **Source fields (Angel One FULL quote):**
  - `ltp`: last traded price
  - `percentChange`: change versus the previous day's close
  - `volume`: shares traded today
  - `avgPrice`: today's VWAP (volume-weighted average price)
  - `open`, `close`: today's open and the previous session's close
- **Turnover:** `ltp × volume`, the rupee value traded today (shown in ₹ crore in the tables).

---

## 1. Top Gainers

| | |
|---|---|
| **Rule** | `percentChange > 0` |
| **Sorted by** | `percentChange`, highest first |
| **Shown** | Top N |

A stock is in the table if it is up on the day and is one of the N biggest risers in the universe.

## 2. Top Losers

| | |
|---|---|
| **Rule** | `percentChange < 0` |
| **Sorted by** | `percentChange`, lowest (most negative) first |
| **Shown** | Top N |

The mirror image of Top Gainers. A stock can never be in both.

## 3. Most Active

| | |
|---|---|
| **Rule** | none (every stock is eligible) |
| **Sorted by** | Turnover (`ltp × volume`), highest first |
| **Shown** | Top N |

This ranks by rupees traded, not share count, so expensive and heavily traded stocks rank high. The direction of the move doesn't matter, so a stock can be here and in Gainers, or here and in Losers.

## 4. High Volume

| | |
|---|---|
| **Rule** | none |
| **Sorted by** | `volume` (raw shares), highest first |
| **Shown** | Top N |

This favors low-priced stocks, because the same rupees buy more shares. It is not used for recommendations.

## 5. Volume Surge (RVOL)

| | |
|---|---|
| **Rule** | `RVOL >= min RVOL` (sidebar, default 2.0) |
| **Sorted by** | RVOL, highest first |
| **Shown** | Top N |

**RVOL (relative volume)** compares today's volume with what is normal by this time of day:

```
expected_volume_now = avg_volume_20d × (minutes since 09:15 IST ÷ 375)
RVOL                = today's volume ÷ expected_volume_now
```

- `avg_volume_20d` is the average daily volume over the previous ~20 trading days (today's candle excluded). It is loaded once per day.
- RVOL of 2.0 means the stock is trading at twice its normal pace.
- Stocks with no historical volume data are skipped.

**Caveat:** the formula assumes volume is spread evenly through the day, but volume is heaviest at the open. So RVOL looks inflated in the first hour and is most reliable from mid-morning. After 15:30 IST the full 375 minutes is used.

## 6. VWAP Tables (Above / Below)

First: `deviation % = (ltp − avgPrice) ÷ avgPrice × 100`. Stocks with no VWAP yet (`avgPrice <= 0`) are skipped.

| Table | Rule | Sorted by |
|---|---|---|
| **Above VWAP (bullish)** | deviation ≥ +threshold (sidebar, default 0.5%) | Largest positive deviation first |
| **Below VWAP (bearish)** | deviation ≤ −threshold | Most negative deviation first |

A stock well above VWAP means the day's volume-weighted buyers are in profit, which traders read as buyers being in control. Below VWAP is the opposite.

## 7. Gap Scanner

```
gap % = (today's open − previous close) ÷ previous close × 100
```

| | |
|---|---|
| **Rule** | `abs(gap %) >= min gap` (sidebar, default 2.0%) |
| **Direction** | "Gap Up" if the gap is positive, "Gap Down" if negative |
| **Sorted by** | Size of the gap, largest first (either direction) |

The table shows where the stock opened, not where it is now. A stock can gap up 3% and then fall back, so also check `ltp` and `percentChange`.

## 8. Range Breakout ↑ and Breakdown ↓

These use the **opening range**: the high and low of the first 15 minutes (09:15 to 09:30 IST, three 5-minute candles). It is loaded once, after 09:30 IST on trading days. Before then the tables show "Opening range forms at 09:30 IST."

| Table | Rule | Sorted by |
|---|---|---|
| **Range Breakout ↑** | `ltp > opening-range high` | `(ltp − or_high) ÷ or_high × 100`, largest first |
| **Range Breakdown ↓** | `ltp < opening-range low` | `(or_low − ltp) ÷ or_low × 100`, largest first |

Both hold the stocks currently trading beyond their first-15-minute range. A stock that broke out earlier and then fell back inside the range is no longer shown.

---

## 9. ⭐ Recommended Stocks

A stock is recommended when it appears in **at least `min tables` (sidebar, default 2)** of these four tables, each taken at its top N:

1. Top Gainers
2. Top Losers
3. Most Active
4. Volume Surge

The other tables (High Volume, VWAP, Gap, Range Breakout) are **not** counted.

| Column | Meaning |
|---|---|
| `hits` | How many of the four tables the stock is in |
| `appears_in` | Which ones (for example "Gainers, Most Active, Vol Surge") |
| `bias` | **Bullish** if `percentChange > 0`, **Bearish** if `< 0`, otherwise Neutral |
| `vwap_pos` | **Above** or **Below** VWAP (or At / `-` if no VWAP yet) |
| `vwap_dev_pct` | How far price is from VWAP, in % |

Rows are sorted by `hits` (most first), then by the size of the day's move.

**The practical maximum for `hits` is 3, not 4.** Gainers and Losers can never both contain the same stock, so a stock can be at most in (Gainers or Losers) + Most Active + Volume Surge. Setting "Min. tables" to 4 will therefore always give an empty list.

**Example.** With N = 10 and RVOL threshold 2.0, suppose stock ABC is up 4.1% and is the 6th biggest gainer, the 3rd most active by turnover, and trading at 2.8× its normal volume pace (4th highest RVOL). It appears in Gainers, Most Active and Vol Surge, so `hits = 3`, `bias = Bullish`. If its price is above VWAP, `vwap_pos = Above`.

**Why a stock may be missing from the list:**
- It is in only one of the four tables.
- It is just outside the top N of one of them (try raising Rows per table).
- Its RVOL is under the threshold, or it has no volume history.
- It is not in the Nifty 200 list.

---

## 10. 🕘 Seen Today

A log of every stock that has ever been in the Recommended list today. It is updated on every refresh, **only while the market is open** (09:15 to 15:30 IST), and saved to `.cache/seen_<date>.json`.

| Column | Meaning |
|---|---|
| `status` | **On list** if in the Recommended table now, **Dropped** if not |
| `bias_when_seen`, `first_seen`, `first_price` | Bias, time (IST) and price when it first appeared. These never change after that. |
| `last_seen` | The last time it was on the list |
| `since_first_pct` | `(ltp − first_price) ÷ first_price × 100` |
| `in_bias_pct` | Same value, but flipped for Bearish stocks, so **+ means it moved the way its bias predicted** |
| `max_hits` | The highest `hits` it reached |
| `refreshes` | How many refresh cycles it was on the list |

---

## Things to keep in mind

- **Data is slightly delayed.** Each refresh takes about 5 seconds to fetch, so prices can be 5 to 25 seconds old.
- **Tables are rankings, not signals.** A stock being in a table means it is unusual right now. It does not mean it will keep moving.
- **Thresholds are adjustable** in the sidebar: min RVOL, VWAP deviation %, gap %, rows per table, and min tables for a recommendation.
- This dashboard is for your own analysis, not investment advice.